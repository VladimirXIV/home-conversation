CREATE ROLE srv_convers_role WITH password 'srv_convers_role' LOGIN;
COMMIT;