CREATE SCHEMA srv_converse;
ALTER SCHEMA srv_converse OWNER TO srv_convers_role;
COMMIT;

